package net.execheinz.upgrader.client;

import net.execheinz.upgrader.container.UpgraderContainer;
import net.minecraft.client.gui.screen.inventory.ContainerScreen;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import com.mojang.blaze3d.matrix.MatrixStack;

/** Client presentation. The server alone decides the result; this wheel is visual feedback. */
public class UpgraderScreen extends ContainerScreen<UpgraderContainer> {
    private long wheelStart;
    private boolean spinning;
    public UpgraderScreen(UpgraderContainer container, PlayerInventory inventory, ITextComponent title) {
        super(container, inventory, title);
        xSize = 220; ySize = 190; playerInventoryTitleY = 82;
    }
    @Override protected void init() {
        super.init();
        addButton(new Button(guiLeft + 78, guiTop + 57, 64, 20, new StringTextComponent("UPGRADE"), b -> {
            wheelStart = System.currentTimeMillis(); spinning = true;
            if (minecraft != null && minecraft.playerController != null) minecraft.playerController.sendEnchantPacket(container.windowId, 0);
        }));
    }
    @Override protected void drawGuiContainerBackgroundLayer(MatrixStack matrix, float partialTicks, int mouseX, int mouseY) {
        fill(matrix, guiLeft, guiTop, guiLeft + xSize, guiTop + ySize, 0xFF171A24);
        fill(matrix, guiLeft + 2, guiTop + 2, guiLeft + xSize - 2, guiTop + ySize - 2, 0xFF202635);
        fill(matrix, guiLeft + 5, guiTop + 5, guiLeft + xSize - 5, guiTop + 22, 0xFF151821);
        drawCenteredString(matrix, font, "ITEM UPGRADER", guiLeft + xSize / 2, guiTop + 8, 0xFFFFFFFF);
        drawCenteredString(matrix, font, "INPUT", guiLeft + 53, guiTop + 23, 0xFFD6DCEB);
        drawCenteredString(matrix, font, "TARGET", guiLeft + 151, guiTop + 23, 0xFFFFD45C);
        // Gold success arc and moving marker. Cosmetic only; authoritative roll is server-side.
        int cx = guiLeft + 110, cy = guiTop + 44;
        fill(matrix, cx - 27, cy - 2, cx + 27, cy + 2, 0xFF8A6A22);
        fill(matrix, cx - 19, cy - 5, cx + 19, cy + 5, 0xFF30394B);
        fill(matrix, cx - 8, cy - 5, cx + 8, cy + 5, 0xFFD6A832);
        if (spinning) {
            long elapsed = System.currentTimeMillis() - wheelStart;
            int marker = (int)((elapsed / 35L) % 54L) - 27;
            fill(matrix, cx + marker - 1, cy - 11, cx + marker + 2, cy - 4, 0xFFFFFFFF);
            if (elapsed > 2600L) spinning = false;
        } else {
            fill(matrix, cx - 1, cy - 11, cx + 2, cy - 4, 0xFFFFFFFF);
        }
        drawCenteredString(matrix, font, "Choose an item in each slot", cx, guiTop + 70, 0xFFB8C2D8);
        drawCenteredString(matrix, font, "Inventory", guiLeft + 35, guiTop + 82, 0xFFAAB3C8);
        for (int row = 0; row < 3; row++) for (int col = 0; col < 9; col++) slot(matrix, guiLeft + 7 + col * 18, guiTop + 91 + row * 18);
        for (int col = 0; col < 9; col++) slot(matrix, guiLeft + 7 + col * 18, guiTop + 149);
    }
    private void slot(MatrixStack matrix, int x, int y) {
        fill(matrix, x, y, x + 18, y + 18, 0xFF080A10);
        fill(matrix, x, y, x + 18, y + 1, 0xFF48516A);
        fill(matrix, x, y, x + 1, y + 18, 0xFF48516A);
        fill(matrix, x + 17, y, x + 18, y + 18, 0xFF30384D);
        fill(matrix, x, y + 17, x + 18, y + 18, 0xFF30384D);
    }
    @Override public void render(MatrixStack matrix, int mouseX, int mouseY, float partialTicks) {
        renderBackground(matrix); super.render(matrix, mouseX, mouseY, partialTicks); renderHoveredTooltip(matrix, mouseX, mouseY);
    }
}
