package net.execheinz.upgrader.item;

import net.execheinz.upgrader.UpgraderMod;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;
import net.minecraftforge.fml.network.NetworkHooks;

public class UpgraderItem extends Item {
    public UpgraderItem() {
        super(new Item.Properties().maxStackSize(1).group(ItemGroup.TOOLS));
    }
    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, PlayerEntity player, Hand hand) {
        ItemStack held = player.getHeldItem(hand);
        if (!world.isRemote && player instanceof ServerPlayerEntity) {
            NetworkHooks.openGui((ServerPlayerEntity) player, new net.minecraft.inventory.container.INamedContainerProvider() {
                @Override public net.minecraft.util.text.ITextComponent getDisplayName() { return new StringTextComponent("ITEM UPGRADER"); }
                @Override public net.minecraft.inventory.container.Container createMenu(int id, net.minecraft.entity.player.PlayerInventory inv, PlayerEntity p) {
                    return new net.execheinz.upgrader.container.UpgraderContainer(id, inv);
                }
            });
        }
        return ActionResult.resultSuccess(held);
    }
}
