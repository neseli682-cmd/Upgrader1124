package net.execheinz.upgrader;

import net.execheinz.upgrader.container.UpgraderContainer;
import net.execheinz.upgrader.item.UpgraderItem;
import net.minecraft.inventory.container.ContainerType;
import net.minecraft.item.Item;
import net.minecraftforge.common.extensions.IForgeContainerType;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(UpgraderMod.MODID)
public class UpgraderMod {
    public static final String MODID = "upgrader";
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<ContainerType<?>> CONTAINERS = DeferredRegister.create(ForgeRegistries.CONTAINERS, MODID);
    public static final RegistryObject<Item> UPGRADER = ITEMS.register("upgrader", UpgraderItem::new);
    public static final RegistryObject<ContainerType<UpgraderContainer>> UPGRADER_CONTAINER = CONTAINERS.register("upgrader", () -> IForgeContainerType.create(UpgraderContainer::new));

    public UpgraderMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        CONTAINERS.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, UpgraderConfig.SPEC);
    }
}
