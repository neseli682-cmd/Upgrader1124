package net.execheinz.upgrader;

import net.minecraftforge.common.ForgeConfigSpec;
import java.util.Arrays;
import java.util.Collections;

public class UpgraderConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue COOLDOWN_SECONDS;
    public static final ForgeConfigSpec.IntValue ATTEMPT_LIMIT;
    public static final ForgeConfigSpec.IntValue ATTEMPT_WINDOW_SECONDS;
    public static final ForgeConfigSpec.DoubleValue GLOBAL_VALUE_MULTIPLIER;
    public static final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> VALUE_OVERRIDES;
    public static final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> VALUE_MULTIPLIERS;
    public static final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> BLACKLIST;
    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("upgrader");
        COOLDOWN_SECONDS = b.comment("Cooldown between upgrade attempts").defineInRange("cooldownSeconds", 2, 0, 3600);
        ATTEMPT_LIMIT = b.comment("Maximum attempts per rolling time window; 0 disables the limit").defineInRange("attemptLimit", 0, 0, 100000);
        ATTEMPT_WINDOW_SECONDS = b.comment("Rolling attempt window in seconds").defineInRange("attemptWindowSeconds", 60, 1, 86400);
        GLOBAL_VALUE_MULTIPLIER = b.defineInRange("globalValueMultiplier", 1.0D, 0.0001D, 1000000.0D);
        VALUE_OVERRIDES = b.comment("Entries: minecraft:diamond=20").defineList("valueOverrides", Collections.emptyList(), o -> o instanceof String);
        VALUE_MULTIPLIERS = b.comment("Entries: minecraft:iron_ingot=1.5").defineList("valueMultipliers", Collections.emptyList(), o -> o instanceof String);
        BLACKLIST = b.comment("Item registry IDs that cannot be used as input or target").defineList("blacklist", Arrays.asList("minecraft:air"), o -> o instanceof String);
        b.pop(); SPEC = b.build();
    }
}
