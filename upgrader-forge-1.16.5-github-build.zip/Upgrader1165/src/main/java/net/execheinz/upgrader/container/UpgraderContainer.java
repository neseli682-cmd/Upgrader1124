package net.execheinz.upgrader.container;

import net.execheinz.upgrader.UpgraderConfig;
import net.execheinz.upgrader.UpgraderMod;
import net.execheinz.upgrader.value.ItemValueCalculator;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.network.PacketBuffer;
import java.util.Random;

/** Server-authoritative two-slot upgrader: input on the left, requested result on the right. */
public class UpgraderContainer extends Container {
    private final IInventory inputs = new Inventory(2);
    private final PlayerEntity player;
    private long nextAttempt;
    private static final Random RANDOM = new Random();

    public UpgraderContainer(int id, PlayerInventory inventory) { this(id, inventory, null); }
    public UpgraderContainer(int id, PlayerInventory inventory, PacketBuffer data) {
        super(UpgraderMod.UPGRADER_CONTAINER.get(), id);
        this.player = inventory.player;
        addSlot(new Slot(inputs, 0, 44, 35));
        addSlot(new Slot(inputs, 1, 142, 35));
        for (int row = 0; row < 3; ++row)
            for (int col = 0; col < 9; ++col)
                addSlot(new Slot(inventory, col + row * 9 + 9, 8 + col * 18, 92 + row * 18));
        for (int col = 0; col < 9; ++col)
            addSlot(new Slot(inventory, col, 8 + col * 18, 150));
    }

    @Override public boolean canInteractWith(PlayerEntity player) { return inputs.isUsableByPlayer(player); }

    @Override public boolean enchantItem(PlayerEntity player, int button) {
        if (button != 0 || player.world.isRemote) return button == 0;
        attemptUpgrade(player);
        return true;
    }

    private void attemptUpgrade(PlayerEntity player) {
        long now = System.currentTimeMillis();
        if (now < nextAttempt) { player.sendMessage(new StringTextComponent("Please wait before trying again."), player.getUniqueID()); return; }
        ItemStack input = inputs.getStackInSlot(0);
        ItemStack target = inputs.getStackInSlot(1);
        if (input.isEmpty() || target.isEmpty()) { player.sendMessage(new StringTextComponent("Place an input and a target item in both slots."), player.getUniqueID()); return; }
        if (ItemValueCalculator.isBlacklisted(input) || ItemValueCalculator.isBlacklisted(target)) {
            player.sendMessage(new StringTextComponent("That item is blacklisted in the Upgrader config."), player.getUniqueID()); return;
        }
        if (input.getItem() == target.getItem() && input.getTag() == null && target.getTag() == null) {
            player.sendMessage(new StringTextComponent("Choose a different target item."), player.getUniqueID()); return;
        }
        nextAttempt = now + UpgraderConfig.COOLDOWN_SECONDS.get() * 1000L;
        double chance = ItemValueCalculator.successChance(input, target, player.world);
        boolean won = RANDOM.nextDouble() < chance;
        input.shrink(1);
        if (won) {
            ItemStack reward = target.copy(); reward.setCount(1);
            if (!player.inventory.addItemStackToInventory(reward)) player.dropItem(reward, false);
            player.world.playSound(null, player.getPosX(), player.getPosY(), player.getPosZ(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.8F, 1.0F);
            player.sendMessage(new StringTextComponent(String.format(java.util.Locale.ROOT, "SUCCESS! Chance: %.1f%%", chance * 100.0D)), player.getUniqueID());
        } else {
            player.world.playSound(null, player.getPosX(), player.getPosY(), player.getPosZ(), SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.PLAYERS, 0.5F, 0.7F);
            player.sendMessage(new StringTextComponent(String.format(java.util.Locale.ROOT, "FAILED. Input lost. Chance: %.1f%%", chance * 100.0D)), player.getUniqueID());
        }
        inputs.markDirty();
    }

    @Override public ItemStack transferStackInSlot(PlayerEntity player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = inventorySlots.get(index);
        if (slot != null && slot.getHasStack()) {
            ItemStack source = slot.getStack(); result = source.copy();
            if (index < 2) { if (!mergeItemStack(source, 2, inventorySlots.size(), true)) return ItemStack.EMPTY; }
            else if (!mergeItemStack(source, 0, 2, false)) return ItemStack.EMPTY;
            if (source.isEmpty()) slot.putStack(ItemStack.EMPTY); else slot.onSlotChanged();
        }
        return result;
    }
    @Override public void onContainerClosed(PlayerEntity player) { super.onContainerClosed(player); if (!player.world.isRemote) clearContainer(player, player.world, inputs); }
}
