package net.execheinz.upgrader.client;

import net.execheinz.upgrader.UpgraderMod;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.client.gui.ScreenManager;

@Mod.EventBusSubscriber(modid = UpgraderMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> ScreenManager.registerFactory(UpgraderMod.UPGRADER_CONTAINER.get(), UpgraderScreen::new));
    }
}
