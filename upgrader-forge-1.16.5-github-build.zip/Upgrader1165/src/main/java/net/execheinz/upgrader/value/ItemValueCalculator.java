package net.execheinz.upgrader.value;

import net.execheinz.upgrader.UpgraderConfig;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Rarity;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.world.World;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

/** Server-side recursive recipe valuation. Values are relative, not currency. */
public final class ItemValueCalculator {
    private static final int MAX_DEPTH = 24;
    private static final double CYCLE_FALLBACK = 1.0D;
    private ItemValueCalculator() {}

    public static double value(ItemStack stack, World world) {
        if (stack == null || stack.isEmpty()) return 0.0D;
        Map<Item, Double> memo = new HashMap<>();
        double base = itemValue(stack.getItem(), world, memo,
                Collections.newSetFromMap(new IdentityHashMap<Item, Boolean>()), 0);
        if (stack.isDamageable()) {
            double remaining = Math.max(0.0D, stack.getMaxDamage() - stack.getDamage());
            base *= remaining / (double) stack.getMaxDamage();
        }
        String id = itemId(stack.getItem());
        Double override = configuredValue(UpgraderConfig.VALUE_OVERRIDES.get(), id);
        if (override != null) base = override;
        Double multiplier = configuredValue(UpgraderConfig.VALUE_MULTIPLIERS.get(), id);
        if (multiplier != null) base *= multiplier;
        base *= UpgraderConfig.GLOBAL_VALUE_MULTIPLIER.get();
        return Math.max(0.0D, base * stack.getCount());
    }

    private static double itemValue(Item item, World world, Map<Item, Double> memo,
                                    Set<Item> visiting, int depth) {
        Double cached = memo.get(item);
        if (cached != null) return cached;
        if (depth >= MAX_DEPTH || visiting.contains(item)) return rarityFallback(item);
        visiting.add(item);
        double best = Double.POSITIVE_INFINITY;
        for (IRecipe<?> recipe : world.getRecipeManager().getRecipes()) {
            ItemStack output = recipe.getRecipeOutput();
            if (output.isEmpty() || output.getItem() != item) continue;
            Ingredient[] ingredients = recipe.getIngredients().toArray(new Ingredient[0]);
            double cost = 0.0D;
            boolean valid = ingredients.length > 0;
            for (Ingredient ingredient : ingredients) {
                ItemStack[] choices = ingredient.getMatchingStacks();
                if (choices.length == 0) { valid = false; break; }
                double cheapest = Double.POSITIVE_INFINITY;
                for (ItemStack choice : choices) {
                    if (!choice.isEmpty()) cheapest = Math.min(cheapest,
                            itemValue(choice.getItem(), world, memo, visiting, depth + 1));
                }
                if (!Double.isFinite(cheapest)) { valid = false; break; }
                cost += cheapest;
            }
            if (valid) best = Math.min(best, cost / Math.max(1, output.getCount()));
        }
        visiting.remove(item);
        if (!Double.isFinite(best) || best <= 0.0D) best = rarityFallback(item);
        memo.put(item, best);
        return best;
    }

    private static String itemId(Item item) {
        return net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(item).toString();
    }

    private static Double configuredValue(java.util.List<? extends String> entries, String id) {
        for (String entry : entries) {
            int split = entry.indexOf('=');
            if (split <= 0 || !entry.substring(0, split).trim().equals(id)) continue;
            try { return Double.parseDouble(entry.substring(split + 1).trim()); }
            catch (NumberFormatException ignored) { return null; }
        }
        return null;
    }

    public static boolean isBlacklisted(ItemStack stack) {
        return !stack.isEmpty() && UpgraderConfig.BLACKLIST.get().contains(itemId(stack.getItem()));
    }

    private static double rarityFallback(Item item) {
        Rarity rarity = item.getRarity(new ItemStack(item));
        switch (rarity) {
            case UNCOMMON: return 3.0D;
            case RARE: return 8.0D;
            case EPIC: return 20.0D;
            default: return 1.0D;
        }
    }

    public static double successChance(ItemStack input, ItemStack target, World world) {
        double targetValue = value(target, world);
        if (targetValue <= 0.0D) return 0.001D;
        double raw = 0.9D * value(input, world) / targetValue;
        return Math.max(0.001D, Math.min(0.90D, raw));
    }
}
