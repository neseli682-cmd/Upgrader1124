# Item Upgrader — Forge 1.16.5

Source project for Minecraft Forge 1.16.5 (Forge 36.2.39), Java 8.

## Current implementation
- Registers one `Upgrader` item; right-click opens its container.
- Two server-side input slots: source item and requested target item.
- The server computes success chance as `clamp(0.9 * sourceValue / targetValue, 0.001, 0.90)` and performs the random roll server-side.
- On success, one requested target item is granted; on failure, one source item is consumed.
- Values are recursively estimated from registered recipe ingredients, with rarity fallback for items without a usable recipe.
- Damageable items are discounted by remaining durability.
- Config includes global multiplier, per-item overrides, per-item multipliers, blacklist, cooldown, and attempt-window settings.
- Client wheel marker is a visual animation only; the server controls the outcome.

## Config syntax
Config file: `config/upgrader-common.toml`

- `valueOverrides`: entries such as `"minecraft:diamond=20"`
- `valueMultipliers`: entries such as `"minecraft:iron_ingot=1.5"`
- `blacklist`: registry IDs such as `"minecraft:grass"`
- `globalValueMultiplier`: numeric multiplier applied to all values
- `attemptLimit` / `attemptWindowSeconds`: reserved config entries; rolling-window enforcement still needs implementation.

## Build
Use a JDK 8 installation and Gradle 4.9 (ForgeGradle 3.x compatible). From this directory run:

```bash
gradle build
```

The mod jar should be produced in `build/libs/` if compilation succeeds.

## Known incomplete parts
This is not yet a feature-complete recreation of the described reference mod. In particular:
- The target is selected by placing it in the right slot; the searchable/scrollable item catalogue is not implemented.
- The wheel is a simple client-side marker animation, not a polished segmented roulette or synchronized result reveal.
- Rolling attempt-limit enforcement is not implemented yet (the config keys are present).
- Recipe valuation uses Forge/Minecraft recipe ingredient data generically; it has not been tested against every modded recipe implementation or all special NBT-driven outputs.
- This project has not been compiled or run in a Minecraft client/server in this environment.
